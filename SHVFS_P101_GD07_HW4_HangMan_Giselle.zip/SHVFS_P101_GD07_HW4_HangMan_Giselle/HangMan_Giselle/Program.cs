﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HangMan_Giselle
{
    class Program
    {
        public static string title = "Hang Man";
        public static int WrongTime = 0;
        public static  bool win = false;
        public static string[] Words = new string[17];
        static void Main(string[] args)
        {

            Words[0] = "giselle";
            Words[1] = "michael";
            Words[2] = "kevin";
            Words[3] = "estelle";
            Words[4] = "eazy";
            Words[5] = "gary";
            Words[6] = "chloe";
            Words[7] = "claire";
            Words[8] = "rebecca";
            Words[9] = "ida";
            Words[10] = "ray";
            Words[11] = "ben";
            Words[12] = "tristan";
            Words[13] = "leo";
            Words[14] = "cindy";
            Words[15] = "oli";
            Words[16] = "chris";
            while (true)
            {
                //Write title
                Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(title);
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("Welcome to Giselle's HangMan game! \n "
                                               + "This is a word for you to guess!\n"
                                               + "It's from the name of a member of GD07(in small letter\n"
                                               + "Choose from the following letters: \na b  c  d  e  g  h  i\nl  m  n  o  r  s  t  y  z");
                Console.ForegroundColor = ConsoleColor.Yellow;


                //Start the game
                WrongTime = 0;
                Game();
                Console.WriteLine("Enter 'r' to replay the game !");
                while (Console.Read() != 'r')
                {
                    Console.Clear();
                    Console.WriteLine("Enter 'r' to replay the game !");
                }
                Console.Clear();
            }
        }
         public static void LooseJudgement()
        {

            if (WrongTime == 1)
            {
                Console.CursorTop = 1;
                Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2;
                Console.WriteLine("------------------");
            }
            else if (WrongTime == 2)
            {
                for (int j = 2; j < 15; j++)
                {
                    Console.CursorTop = j;
                    Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2 - 1;
                    Console.WriteLine("|");
                }
            }
            else if (WrongTime == 3)
            {
                Console.CursorTop = 2;
                Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2 + 8;
                Console.WriteLine("|");
            }
            else if (WrongTime == 4)
            {
                Console.CursorTop = 3;
                Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2 + 7;
                Console.WriteLine("---");
                Console.CursorTop = 4;
                Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2 + 6;
                Console.WriteLine("|");
                Console.CursorTop = 4;
                Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2 + 10;
                Console.WriteLine("|");
                Console.CursorTop = 5;
                Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2 + 7;
                Console.WriteLine("---");
            }
            else if (WrongTime == 5)
            {
                for (int j = 6; j < 10; j++)
                {
                    Console.CursorTop = j;
                    Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2 + 8;
                    Console.WriteLine("|");
                }
            }
            else if (WrongTime == 6)
            {

                Console.CursorTop = 7;
                Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2 + 6;
                Console.WriteLine("/");
                Console.CursorTop = 8;
                Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2 + 5;
                Console.WriteLine("/");
            }
            else if (WrongTime == 7)
            {
                Console.CursorTop = 7;
                Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2 + 10;
                Console.WriteLine(@"\");
                Console.CursorTop = 8;
                Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2 + 11;
                Console.WriteLine(@"\");
            }
            else if (WrongTime == 8)
            {
                Console.CursorTop = 10;
                Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2 + 9;
                Console.WriteLine(@"\");
                Console.CursorTop = 11;
                Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2 + 10;
                Console.WriteLine(@"\");
            }
            else if (WrongTime == 9)
            {
                win = false;
                Console.CursorTop = 10;
                Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2 + 7;
                Console.WriteLine("/");
                Console.CursorTop = 11;
                Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2 + 6;
                Console.WriteLine("/");
            }
        }

        public static void Game()
        {
            //Choose a random word from the stock
            Random rd = new Random();
            int i = rd.Next(0, 16);
            string TrueWord = Words[i];
            //Define the Correct Answer and define the number of spaces and correspond them
            char[] truth = new char[TrueWord.Length];
            char[] word = new char[TrueWord.Length];
            for (int t = 0; t < TrueWord.Length; t++)
            {
                truth[t] = Words[i][t];
             //Write spaces
                word[t] = '_';
                Console.CursorTop = 9;
                Console.CursorLeft = 2 * t;
                Console.WriteLine($"{ word[t]}");
            }
            int right = 0;
            //Start to guess
            while (true)
            {
                Console.WriteLine("Guess a letter :");
                bool correct = false;
                char guess = (char)Console.Read();
                int guessnumber = Convert.ToInt32(guess);
                //Remind the player of entering small letter in case they don't
                if (guessnumber< 97)
                {
                    Console.WriteLine("Please enter a small letter");
                    System.Threading.Thread.Sleep(1000);
                    Console.CursorTop = 12;
                    Console.WriteLine("                                          ");
                }
                //Search through the correct answer~
                for (int b = 0; b < truth.Length; b++)
                {
                    if (guess == truth[b] && guess != word[b])
                    {
                        correct = true;
                        word[b] = truth[b];
                        right++;
                    }
                    else if (guess == word[b])
                    {
                        Console.WriteLine("Already Exist!!");
                        break;
                    }
                }
                //Conditions
                if (correct == false)
                {
                    WrongTime++;
                    LooseJudgement();
                }
                //Win/Loose Judgement
                if (right == truth.Length)
                {
                    win = true;
                    break;
                }
                if (WrongTime == 9 && win == false)
                {
                    break;
                }
                Console.ReadLine();
                Console.CursorTop = 8;

                for (int t = 0; t < TrueWord.Length; t++)
                {
                    Console.CursorTop = 9;
                    Console.CursorLeft = 2 * t;
                    Console.WriteLine($"{ word[t]}");
                }
            }

            if (win == true)
            {
                for (int t = 0; t < TrueWord.Length; t++)
                {
                    Console.CursorTop =9;
                    Console.CursorLeft = 2 * t;
                    Console.WriteLine($"{ word[t]}");
                }
                Console.CursorTop = 12;
                Console.WriteLine("You Win!!!!!!!!!!!");
            }
            else if (win == false)
            {
                Console.CursorTop = 12;
                Console.WriteLine("You loose!The little man is hanged............OHNOOOOOO....\n" 
                                                  +$"The correct answer is   {TrueWord} ");

            }
            Console.ReadLine();
            Console.ReadLine();
        }
    }
}


